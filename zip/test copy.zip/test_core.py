# Basic test for CLI core

def test_show_landing():
    # This is a placeholder for future tests
    assert True
